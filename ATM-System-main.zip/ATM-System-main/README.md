# ATM-System
This project is done by using JDBC Connection in Java
